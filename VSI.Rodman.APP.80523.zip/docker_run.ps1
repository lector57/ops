$theme = ("#{UI_THEME}" -split "=")[1];
cat "#{PROJECT_FOLDER}\.env" > "#{PROJECT_FOLDER}\.env_$theme";
"#{SUM_ENV}" -Split "#{SEPARATOR}" >> "#{PROJECT_FOLDER}\.env_$theme";
docker rm -f VSI.Rodman.APP.$theme  2> $null;
docker pull 3pweb08a.vsvendor.local:5001/vsi.rodman.app:80522;
docker run -d --restart unless-stopped --name VSI.Rodman.APP.$theme #{PORT_MAPPING} --env-file="#{PROJECT_FOLDER}/.env_$theme" --log-driver=loki --log-opt loki-url=http://3PWEB08A.vsvendor.local:3100/loki/api/v1/push --log-opt loki-retries=5 --log-opt loki-batch-size=400 3pweb08a.vsvendor.local:5001/vsi.rodman.app:80522
